NoCharge media kit
==================

Contents
--------
brand/         Brand symbol (SVG, black, white), dark/light lockups, and a 512x512 PNG symbol.
social/        Default social card (JPG 1200x630) and square avatar (PNG 512x512).
game-covers/   One square cover (WebP 800x800) per game: memory-match, word-tile-rush,
               color-flip, beacon-lattice.
screenshots/   beacon-lattice.webp — the only genuine mounted-DOM gameplay capture on file.
FACTS.txt      Snapshot of the canonical facts; the HTML page at https://nocharge.net/media/
               is the canonical source.

Usage guidance
--------------
- Use the files as provided. Do not distort, rotate, redraw, or recombine the symbol.
- Preserve clear space and do not crop the open doorway.
- Do not recolor the mark outside the approved variants (black, white, brand green,
  deep green on light backgrounds).
- Do not imply endorsement or sponsorship by NoCharge.
- Do not present generated concept art or previews as gameplay.
- Write "NoCharge" and the game names accurately: Memory Match, Word Tile Rush,
  Color Flip, Beacon Lattice.

Contact
-------
hello@nocharge.net

Regeneration
------------
The archive is generated deterministically from the committed assets with:
  npm run kit:media
The generation script and validation checks live in scripts/generate-media-kit.mjs
and scripts/validate-media-kit.mjs.
